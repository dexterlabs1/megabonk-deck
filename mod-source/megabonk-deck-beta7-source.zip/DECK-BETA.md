# Deck beta 7 - native main-menu controller startup

The mod now manages cursor visibility and locking only while a mod dialog is
open. The native main menu retains its own cursor ownership and input-mode
selection. The user verified a cold launch on the physical Deck: built-in D-pad
navigation and A opened Together immediately without mouse intervention.

Beta 6 modal navigation, the gold selection marker, character-menu handoff, and
earlier hover/layout corrections remain. Protocol and assembly version stay 5.1.0.
Two-player joining, match start, extended play, a fresh physical installation,
and the built-in STEAM+X keyboard still require testing.

# Deck beta 6 - restore modal controller navigation

Live Deck testing exposed a Unity/IL2CPP array-return mismatch in three modal
controller calls. Beta 6 routes these calls through the existing runtime helper,
which adapts the generated IL2CPP array. This targets background-menu selection
and repeated input exceptions while Together dialogs are open. Modal focus now
remains inside its visible buttons on every frame; background Unity navigation
is disabled temporarily and restored exactly on close. Custom buttons show their
hover/default colors by setting the graphic directly, with no native virtual
base hover calls. Optional hover callbacks still run after default feedback. A
gold controller selection marker is refreshed explicitly every frame, independent
of native hover dispatch, and original modal colors are restored on close.
Successful hosting/joining releases modal controller ownership before character
selection; delayed cleanup uses real time, so paused menus cannot stall it. The
network entry dialog cannot capture controller focus outside the main menu. Earlier hover,
main-menu navigation, and Friendlies layout changes remain. Protocol and assembly
version remain 5.1.0.

Build and compiled-IL regression checks are required before packaging. Physical
Deck modal focus, Back, manual typing, and multiplayer remain acceptance checks.

## Previous beta 5 changes

Beta 5 separates the Friendlies title, Host, room-code input, keyboard hint,
Paste/Join buttons, status message and Back into non-overlapping rows. The panel
is opaque. Select the room-code field with the mouse or controller A, then press
STEAM+X to type. Paste is optional. Input now permits all 32 characters accepted
by validation, and the text viewport/caret and native button references are explicit.
The Together version label stays on one line. Protocol/assembly remain 5.1.0.

Beta 3's hover recursion correction and beta 4's main-menu navigation and sizing
corrections are retained. A solo host still needs a second player to confirm.

Layout/stub tests and compiled-IL checks do not execute native Unity/IL2CPP.
Manual typing, controller focus and two-Deck multiplayer still need live testing.

## Changes

- Register Together in the game's native controller navigation.
- Restrict native navigation to visible mod-dialog buttons while a dialog is open;
  restore the previous button list, button lookup set, and focus on close.
- Preserve managed hover callbacks, prevent duplicate Together dialogs, and block clicks
  through dialog backgrounds.
- B backs out of text input, submenus, and dialogs; while connecting it cancels.
- Make room-code/name fields controller selectable; use STEAM+X for the keyboard.
- Keep the cursor unlocked and visible in the main menu and mod dialogs.
  Steam Input must still map the right trackpad to Mouse to send mouse movement.
- On-screen control hints; Paste Code; remember the last attempted join code for
  this game session only; validate codes; 200 ms submit guard on opening dialogs.
- Host's lobby has Show Room Code / Hide Room Code. Share that code with your
  friend, who enters it in Together > Friendlies to join. Revealing the code uses
  only local UI: no Steam overlay, native callback, or clipboard write.
- Upgrades beta 1 directly while retaining the original official DLL backup.

## Validation and limits

Compiled in Release for Proton. Pure room-code parsing and removal checks, plus
installer upgrade/restore filesystem tests, run without Steam.
**Not tested on a physical Steam Deck, in-game Unity UI, or a live multiplayer
session.** Beta 2 removes the suspected native invite path rather than claiming
that the user's freeze has been reproduced. Steam invites and automatic joining
are unavailable. Normal room-code joining is unchanged.

## Build

Install .NET SDK 8. Fetch the exact upstream source to obtain the compile-only
stripped reference DLLs (not full game DLLs):

```sh
git clone https://github.com/Fcornaire/megabonk-together.git upstream-refs
git -C upstream-refs checkout 009e4bac2731364cbcebe8324f1fbce34c528806
cp -R upstream-refs/src/plugin/stripped-libs src/plugin/
CI=true PROTON_BUILD=true dotnet build src/plugin/MegabonkTogether.Plugin.csproj -c Release
```

Publish only `src/plugin/bin/Release/net6.0/MegabonkTogether.dll` over an existing
5.1.0 Proton installation. Keep the existing dependencies. Do not distribute full
original game assemblies. The source archive includes all modified and unmodified
plugin/common C# sources, project files, tests and the upstream GPL license;
compile-only reference binaries and generated build outputs are excluded.

Run the pure room-code/removal checks, supplying BepInEx core and reference folders:

```sh
dotnet run --project tests/DeckSmoke -- \
  src/plugin/bin/Release/net6.0/MegabonkTogether.dll \
  /path/to/BepInEx/core src/plugin/stripped-libs/interop src/plugin/stripped-libs/unity-libs
```

Before calling the beta stable, verify: D-pad reaches Together; A opens once;
Friendlies/Host/Join/name/code/Paste can be selected; B backs out once; menus behind
popups do not react; cursor works with a Mouse trackpad binding; gameplay controls
are unchanged; Show/Hide Room Code works without opening the overlay; manual code joining works; restore launcher restores the prior DLL.

## Inspiration and credits

Built from DShad/Fcornaire's Megabonk Together; see LICENSE (GPL version 2).
Quality-of-life ideas reviewed: SpacebarBlock's protection against accidental
confirmations; SimpleUITweaks' readability emphasis; MoreKeybinds' faster UI access.
No code from those mods was copied. No damage, loot, experience, or progression
cheats were added.

- https://thunderstore.io/c/megabonk/p/guarnecessities/SpacebarBlock/
- https://thunderstore.io/c/megabonk/p/Maskoliver/SimpleUITweaks/
- https://thunderstore.io/c/megabonk/p/bedlesssleeper/MoreKeybinds/
