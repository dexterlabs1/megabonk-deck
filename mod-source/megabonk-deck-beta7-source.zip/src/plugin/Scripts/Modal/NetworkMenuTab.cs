using Assets.Scripts.Settings___Saves.SaveFiles;
using MegabonkTogether.Common.Models;
using MegabonkTogether.Configuration;
using MegabonkTogether.Helpers;
using MegabonkTogether.Scripts.Button;
using MegabonkTogether.Scripts.Modal;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

namespace MegabonkTogether.Scripts
{
    internal class NetworkMenuTab : ModalBase
    {
        internal override MyButton DefaultControllerButton
        {
            get
            {
                if (stopButton != null && stopButton.gameObject.activeInHierarchy) return stopButton;
                if (hostButton != null && hostButton.gameObject.activeInHierarchy)
                    return string.IsNullOrEmpty(codeInput.text) ? hostButton : joinButton;
                if (friendliesButton != null && friendliesButton.gameObject.activeInHierarchy) return friendliesButton;
                return netplayOptionsBackButton;
            }
        }
        protected override Color PanelBackgroundColor => new Color(0.1f, 0.1f, 0.1f, 1f);
        private GameObject codeKeyboardHint;
        private GameObject controlHints;
        private static string lastRoom = "";
        private CustomButton pasteButton;
        private CustomButton randomButton;
        private CustomButton friendliesButton;
        private CustomButton closeButton;
        private CustomButton stopButton;
        private TMP_InputField playerNameInput;
        private MainMenu mainMenu;
        private GameObject label;
        private bool wasInputFocused;
        private Coroutine connectionCoroutine;
        private ProfanityFilter.ProfanityFilter filter;

        private GameObject friendliesTitle;
        private CustomButton hostButton;
        private CustomButton joinButton;
        private CustomButton friendliesBackButton;
        private TMP_InputField codeInput;
        private GameObject codeLabel;

        private GameObject saveToggleSetting;
        private CustomButton saveToggleLeftButton;
        private CustomButton saveToggleRightButton;
        private TextMeshProUGUI saveToggleStatusText;

        private CustomButton netplayOptionsButton;
        private GameObject netplayOptionsTitle;
        private CustomButton netplayOptionsBackButton;
        private GameObject sharedExpToggleSetting;
        private CustomButton sharedExpToggleLeftButton;
        private CustomButton sharedExpToggleRightButton;
        private TextMeshProUGUI sharedExpToggleStatusText;

        internal override void ControllerBack()
        {
            if (connectionCoroutine != null || (stopButton != null && stopButton.gameObject.activeInHierarchy)) OnStopClicked();
            else if (friendliesBackButton != null && friendliesBackButton.gameObject.activeInHierarchy) OnFriendliesBackClicked();
            else if (netplayOptionsBackButton != null && netplayOptionsBackButton.gameObject.activeInHierarchy) OnNetplayOptionsBackClicked();
            else OnCloseClicked();
        }

        protected void Awake()
        {
            filter = new ProfanityFilter.ProfanityFilter();
        }

        public void SetMainMenu(MainMenu menu)
        {
            mainMenu = menu;
        }

        protected override void OnUICreated()
        {
            CreateCloseButton();
            CreatePlayerNameInput();
            CreateMatchButtons();
            CreateStopButton();
            CreateFriendliesUI();
            CreateNetplayOptionsUI();
            MakeInputNavigable(playerNameInput);
            MakeInputNavigable(codeInput);
            codeInput.text = lastRoom;
            pasteButton = CreateUtilityButton("Paste Code", new Vector2(-145, -80), () =>
            {
                try
                {
                    var text = TextCopy.ClipboardService.GetText()?.Trim();
                    var inviteRoom = RoomCodeTools.ParseRoom(text);
                    var room = inviteRoom ?? text?.ToUpperInvariant();
                    if (!IsValidRoom(room)) { SetStatusText("Clipboard does not contain a valid room code."); return; }
                    codeInput.text = room;
                    SetStatusText("Code pasted. Select Join when ready.");
                }
                catch { SetStatusText("Clipboard unavailable. Select the code field and press STEAM+X."); }
            });
            pasteButton.gameObject.SetActive(false);
            var hints = new GameObject("DeckControlHints");
            controlHints = hints;
            hints.transform.SetParent(panel.transform, false);
            var hintRect = hints.AddComponent<RectTransform>();
            hintRect.anchoredPosition = new Vector2(0, -255);
            hintRect.sizeDelta = new Vector2(650, 32);
            var hintText = hints.AddComponent<TextMeshProUGUI>();
            hintText.text = "D-pad / stick: navigate    A: select    B: back    STEAM+X: keyboard";
            hintText.fontSize = 20;
            hintText.alignment = TextAlignmentOptions.Center;
            hintText.raycastTarget = false;
            ApplyFriendliesLayout();
        }

        private static bool IsValidRoom(string room) =>
            room != null && System.Text.RegularExpressions.Regex.IsMatch(room, "^[A-Z0-9]{4,32}$");

        private CustomButton CreateUtilityButton(string title, Vector2 position, System.Action action)
        {
            var go = GameObject.Instantiate(mainMenu.btnPlay.gameObject, panel.transform, false);
            var original = go.GetComponent<MyButtonNormal>();
            var localized = go.GetComponentInChildren<LocalizeStringEvent>();
            if (localized != null) DestroyImmediate(localized);
            var uiButton = go.GetComponentInChildren<UnityEngine.UI.Button>();
            if (uiButton != null) uiButton.onClick = new();
            var button = go.AddComponent<CustomButton>();
            // Bind the native navigation/visual fields before destroying the template.
            button.button = uiButton;
            if (uiButton != null) uiButton.navigation = Navigation.defaultNavigation;
            if (original != null)
            {
                button.background = original.background;
                button.defaultColor = original.defaultColor;
                button.hoverColor = original.hoverColor;
                button.colorInited = original.colorInited;
                button.disabledOverlay = original.disabledOverlay;
                button.customSfx = original.customSfx;
                button.state = original.state;
                button.scaleOnHover = original.scaleOnHover;
                button.hoverScale = original.hoverScale;
                DestroyImmediate(original);
            }
            button.SetOnClickAction(action);
            var label = go.GetComponent<ButtonTextWrapper>().t_text;
            label.text = title;
            label.fontSize = 28;
            label.enableWordWrapping = false;
            SetLayout(go, position.x, position.y, 260, 54);
            button.SetInteractable(true);
            return button;
        }

        private void MakeInputNavigable(TMP_InputField input)
        {
            // TMP_InputField already inherits Selectable. Put the controller
            // proxy on a child; Unity forbids a second Selectable on the field.
            var proxyObject = new GameObject("ControllerInputFocus");
            proxyObject.transform.SetParent(input.transform, false);
            var rect = proxyObject.AddComponent<RectTransform>();
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.sizeDelta = Vector2.zero;
            rect.anchoredPosition = Vector2.zero;
            var highlight = proxyObject.AddComponent<Image>();
            highlight.color = new Color(0, 0, 0, 0);
            highlight.raycastTarget = false;
            var uiButton = proxyObject.AddComponent<UnityEngine.UI.Button>();
            uiButton.targetGraphic = highlight;
            var proxy = proxyObject.AddComponent<CustomButton>();
            uiButton.navigation = Navigation.defaultNavigation;
            proxy.button = uiButton;
            proxy.background = highlight;
            proxy.defaultColor = new Color(0, 0, 0, 0);
            proxy.hoverColor = new Color(0.3f, 0.5f, 0.7f, 0.3f);
            proxy.SetOnClickAction(() => { input.Select(); input.ActivateInputField(); });
            proxy.OverrideStartHoverAction(() => { highlight.color = proxy.hoverColor; });
            proxy.OverrideEndHoverAction(() => { highlight.color = proxy.defaultColor; });
            proxy.SetInteractable(true);
        }

        private void CreateCloseButton()
        {
            closeButton = CreateUtilityButton("Close", new Vector2(0, -200), OnCloseClicked);
            SetLayout(closeButton.gameObject, 0, -200, 300, 70);
        }

        private void CreatePlayerNameInput()
        {
            var inputObj = new GameObject("PlayerNameInput");
            inputObj.transform.SetParent(panel.transform, false);

            var rectTransform = inputObj.AddComponent<RectTransform>();
            rectTransform.anchorMin = new Vector2(0.5f, 0.7f);
            rectTransform.anchorMax = new Vector2(0.5f, 0.7f);
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchoredPosition = Vector2.zero;
            rectTransform.sizeDelta = new Vector2(300, 50);

            var image = inputObj.AddComponent<Image>();
            image.color = new Color(0.2f, 0.2f, 0.2f, 1f);

            playerNameInput = inputObj.AddComponent<TMP_InputField>();
            playerNameInput.textComponent = CreateInputText(inputObj);
            playerNameInput.placeholder = CreatePlaceholderText(inputObj);
            playerNameInput.text = ModConfig.PlayerName.Value;
            playerNameInput.characterLimit = 20;

            playerNameInput.caretWidth = 3;
            playerNameInput.caretColor = Color.white;
            playerNameInput.customCaretColor = true;
            playerNameInput.caretBlinkRate = 0.85f;

            playerNameInput.selectionColor = new Color(0.65f, 0.8f, 1f, 0.5f);

            // Enable/disable to force caret initialization (Thanks random user on Stack exchange)
            playerNameInput.enabled = false;
            playerNameInput.enabled = true;

            label = new GameObject("Label");
            label.transform.SetParent(panel.transform, false);

            var labelRect = label.AddComponent<RectTransform>();
            labelRect.anchorMin = new Vector2(0.5f, 0.75f);
            labelRect.anchorMax = new Vector2(0.5f, 0.75f);
            labelRect.pivot = new Vector2(0.5f, 0.5f);
            labelRect.anchoredPosition = new Vector2(0, 25);
            labelRect.sizeDelta = new Vector2(300, 40);

            var labelText = label.AddComponent<TextMeshProUGUI>();
            labelText.text = "Player Name:";
            labelText.alignment = TextAlignmentOptions.Center;
            labelText.fontSize = 50;
            labelText.color = Color.white;
        }

        private void CreateSaveToggle()
        {
            var settings = mainMenu.settings.GetComponent<Settings>();
            var settingPrefab = settings.GetSettingPrefab(SettingType.Enum);

            saveToggleSetting = GameObject.Instantiate(settingPrefab, panel.transform);

            var rectTransform = saveToggleSetting.GetComponent<RectTransform>();
            rectTransform.anchorMin = new Vector2(0.5f, 0.6f);
            rectTransform.anchorMax = new Vector2(0.5f, 0.6f);
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchoredPosition = new Vector2(0, 25);
            rectTransform.sizeDelta = new Vector2(700, 60);

            var textComponents = Il2CppFindHelper.RuntimeGetComponentsInChildren<TextMeshProUGUI>(saveToggleSetting);
            foreach (var textComp in textComponents)
            {
                if (textComp.name.StartsWith("Text"))
                {
                    textComp.text = "Allow Saving progression\nUse at your own risk";
                    textComp.fontSize = 20;
                    textComp.enableWordWrapping = false;
                }
                else if (textComp.name.StartsWith("StatusText"))
                {
                    saveToggleStatusText = textComp;
                    saveToggleStatusText.gameObject.SetActive(true);
                    UpdateSaveToggleStatus();
                }
            }

            var buttons = Il2CppFindHelper.RuntimeGetComponentsInChildren<UnityEngine.UI.Button>(saveToggleSetting);
            foreach (var btn in buttons)
            {
                if (btn.name == "B_Left")
                {
                    var origButton = btn.GetComponent<MyButtonNormal>();
                    if (origButton != null)
                    {
                        UnityEngine.Object.DestroyImmediate(origButton);
                    }

                    btn.onClick = new();

                    saveToggleLeftButton = btn.gameObject.AddComponent<CustomButton>();
                    saveToggleLeftButton.SetOnClickAction(OnSaveToggleLeftClicked);
                }
                else if (btn.name == "B_Right")
                {
                    var origButton = btn.GetComponent<MyButtonNormal>();
                    if (origButton != null)
                    {
                        UnityEngine.Object.DestroyImmediate(origButton);
                    }

                    btn.onClick = new();

                    saveToggleRightButton = btn.gameObject.AddComponent<CustomButton>();
                    saveToggleRightButton.SetOnClickAction(OnSaveToggleRightClicked);
                }
            }

            saveToggleSetting.SetActive(false);
        }

        private void OnSaveToggleLeftClicked()
        {
            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiClick.sounds[0]);
            ToggleSaveOption(false);
        }

        private void OnSaveToggleRightClicked()
        {
            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiClick.sounds[0]);
            ToggleSaveOption(true);
        }

        private void ToggleSaveOption(bool isEnabled)
        {
            ModConfig.AllowSavesDuringNetplay.Value = isEnabled;
            ModConfig.Save();
            UpdateSaveToggleStatus();
        }

        private void UpdateSaveToggleStatus()
        {
            if (saveToggleStatusText != null)
            {
                saveToggleStatusText.text = ModConfig.AllowSavesDuringNetplay.Value ? "ON" : "OFF";
                saveToggleStatusText.color = ModConfig.AllowSavesDuringNetplay.Value ? Color.green : Color.red;
            }
        }

        private void CreateSharedExpToggle()
        {
            var settings = mainMenu.settings.GetComponent<Settings>();
            var settingPrefab = settings.GetSettingPrefab(SettingType.Enum);

            sharedExpToggleSetting = GameObject.Instantiate(settingPrefab, panel.transform);

            var rectTransform = sharedExpToggleSetting.GetComponent<RectTransform>();
            rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchoredPosition = new Vector2(0, -50);
            rectTransform.sizeDelta = new Vector2(700, 60);

            var textComponents = Il2CppFindHelper.RuntimeGetComponentsInChildren<TextMeshProUGUI>(sharedExpToggleSetting);
            foreach (var textComp in textComponents)
            {
                if (textComp.name.StartsWith("Text"))
                {
                    textComp.text = "Shared Experience(Experimental)\nXP/Gold/Interaction shared\nActive pause enabled";
                    textComp.fontSize = 18;
                    textComp.enableWordWrapping = false;
                }
                else if (textComp.name.StartsWith("StatusText"))
                {
                    sharedExpToggleStatusText = textComp;
                    sharedExpToggleStatusText.gameObject.SetActive(true);
                    UpdateSharedExpToggleStatus();
                }
            }

            var buttons = Il2CppFindHelper.RuntimeGetComponentsInChildren<UnityEngine.UI.Button>(sharedExpToggleSetting);
            foreach (var btn in buttons)
            {
                if (btn.name == "B_Left")
                {
                    var origButton = btn.GetComponent<MyButtonNormal>();
                    if (origButton != null)
                    {
                        UnityEngine.Object.DestroyImmediate(origButton);
                    }

                    btn.onClick = new();

                    sharedExpToggleLeftButton = btn.gameObject.AddComponent<CustomButton>();
                    sharedExpToggleLeftButton.SetOnClickAction(OnSharedExpToggleLeftClicked);
                }
                else if (btn.name == "B_Right")
                {
                    var origButton = btn.GetComponent<MyButtonNormal>();
                    if (origButton != null)
                    {
                        UnityEngine.Object.DestroyImmediate(origButton);
                    }

                    btn.onClick = new();

                    sharedExpToggleRightButton = btn.gameObject.AddComponent<CustomButton>();
                    sharedExpToggleRightButton.SetOnClickAction(OnSharedExpToggleRightClicked);
                }
            }

            sharedExpToggleSetting.SetActive(false);
        }

        private void OnSharedExpToggleLeftClicked()
        {
            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiClick.sounds[0]);
            ToggleSharedExpOption(false);
        }

        private void OnSharedExpToggleRightClicked()
        {
            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiClick.sounds[0]);
            ToggleSharedExpOption(true);
        }

        private void ToggleSharedExpOption(bool isEnabled)
        {
            ModConfig.EnabledSharedExperience.Value = isEnabled;
            ModConfig.Save();
            UpdateSharedExpToggleStatus();
        }

        private void UpdateSharedExpToggleStatus()
        {
            if (sharedExpToggleStatusText != null)
            {
                sharedExpToggleStatusText.text = ModConfig.EnabledSharedExperience.Value ? "ON" : "OFF";
                sharedExpToggleStatusText.color = ModConfig.EnabledSharedExperience.Value ? Color.green : Color.red;
            }
        }

        private void CreateNetplayOptionsUI()
        {
            netplayOptionsTitle = new GameObject("NetplayOptionsTitle");
            netplayOptionsTitle.transform.SetParent(panel.transform, false);

            var titleRect = netplayOptionsTitle.AddComponent<RectTransform>();
            titleRect.anchorMin = new Vector2(0.5f, 0.85f);
            titleRect.anchorMax = new Vector2(0.5f, 0.85f);
            titleRect.pivot = new Vector2(0.5f, 0.5f);
            titleRect.anchoredPosition = Vector2.zero;
            titleRect.sizeDelta = new Vector2(400, 60);

            var titleText = netplayOptionsTitle.AddComponent<TextMeshProUGUI>();
            titleText.text = "Netplay Options";
            titleText.alignment = TextAlignmentOptions.Center;
            titleText.fontSize = 60;
            titleText.color = Color.white;

            netplayOptionsTitle.SetActive(false);

            CreateSaveToggle();
            CreateSharedExpToggle();

            var backButtonObj = GameObject.Instantiate(mainMenu.btnPlay.gameObject);
            backButtonObj.transform.SetParent(panel.transform, false);

            var originalBackButton = backButtonObj.GetComponent<MyButtonNormal>();
            if (originalBackButton != null)
            {
                UnityEngine.Object.DestroyImmediate(originalBackButton);
            }

            UnityEngine.UI.Button backButton = backButtonObj.GetComponentInChildren<UnityEngine.UI.Button>();
            if (backButton != null)
            {
                backButton.onClick = new();
            }

            var localizeStringEventBack = backButtonObj.GetComponentInChildren<LocalizeStringEvent>();
            if (localizeStringEventBack != null)
            {
                UnityEngine.Object.DestroyImmediate(localizeStringEventBack);
            }

            netplayOptionsBackButton = backButtonObj.AddComponent<CustomButton>();
            netplayOptionsBackButton.SetOnClickAction(OnNetplayOptionsBackClicked);

            var backTextWrapper = backButtonObj.GetComponent<ButtonTextWrapper>();
            backTextWrapper.t_text.text = "Back";
            backTextWrapper.t_text.fontSize = 36;

            var backRectTransform = backButtonObj.GetComponent<RectTransform>();
            backRectTransform.anchorMin = new Vector2(0.5f, 0.5f);
            backRectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            backRectTransform.pivot = new Vector2(0.5f, 0.5f);
            backRectTransform.anchoredPosition = new Vector2(0, -200f);
            backRectTransform.sizeDelta = new Vector2(300, 70);

            netplayOptionsBackButton.gameObject.SetActive(false);
        }

        private TextMeshProUGUI CreateInputText(GameObject parent)
        {
            var textObj = new GameObject("Text");
            textObj.transform.SetParent(parent.transform, false);

            var rectTransform = textObj.AddComponent<RectTransform>();
            rectTransform.anchorMin = Vector2.zero;
            rectTransform.anchorMax = Vector2.one;
            rectTransform.sizeDelta = Vector2.zero;
            rectTransform.anchoredPosition = Vector2.zero;

            var text = textObj.AddComponent<TextMeshProUGUI>();
            text.alignment = TextAlignmentOptions.Left;
            text.verticalAlignment = VerticalAlignmentOptions.Middle;
            text.fontSize = 35;
            text.color = Color.white;
            text.margin = new Vector4(10, 0, 10, 0);

            return text;
        }

        private TextMeshProUGUI CreatePlaceholderText(GameObject parent)
        {
            var placeholderObj = new GameObject("Placeholder");
            placeholderObj.transform.SetParent(parent.transform, false);

            var rectTransform = placeholderObj.AddComponent<RectTransform>();
            rectTransform.anchorMin = Vector2.zero;
            rectTransform.anchorMax = Vector2.one;
            rectTransform.sizeDelta = Vector2.zero;
            rectTransform.anchoredPosition = Vector2.zero;

            var text = placeholderObj.AddComponent<TextMeshProUGUI>();
            text.text = "Enter your name...";
            text.alignment = TextAlignmentOptions.Left;
            text.verticalAlignment = VerticalAlignmentOptions.Middle;
            text.fontSize = 24;
            text.color = new Color(1f, 1f, 1f, 0.3f);
            text.margin = new Vector4(10, 0, 10, 0);

            return text;
        }

        private void CreateStopButton()
        {
            stopButton = CreateUtilityButton("Stop", new Vector2(0, -220), OnStopClicked);
            SetLayout(stopButton.gameObject, 0, -220, 300, 70);
            stopButton.gameObject.SetActive(false);
        }

        private void CreateMatchButtons()
        {
            randomButton = CreateUtilityButton("Random", new Vector2(-180, -100), OnRandomClicked);
            friendliesButton = CreateUtilityButton("Friendlies", new Vector2(180, -100), OnFriendliesClicked);
            netplayOptionsButton = CreateUtilityButton("Netplay Options", new Vector2(0, -10), OnNetplayOptionsClicked);
            SetLayout(randomButton.gameObject, -180, -100, 300, 70);
            SetLayout(friendliesButton.gameObject, 180, -100, 300, 70);
            SetLayout(netplayOptionsButton.gameObject, 0, -10, 300, 70);
        }

        private void CreateFriendliesUI()
        {
            friendliesTitle = CreateFriendliesLabel("FriendliesTitle", "Friendlies", 50);
            hostButton = CreateUtilityButton("Host", Vector2.zero, OnHostClicked);
            hostButton.gameObject.SetActive(false);
            codeLabel = CreateFriendliesLabel("CodeLabel", "Room Code", 28);
            codeKeyboardHint = CreateFriendliesLabel("CodeKeyboardHint",
                "Select the field, then press STEAM+X to type", 20);

            var codeInputObj = new GameObject("CodeInput");
            codeInputObj.transform.SetParent(panel.transform, false);
            codeInputObj.AddComponent<RectTransform>();
            var codeInputImage = codeInputObj.AddComponent<Image>();
            codeInputImage.color = new Color(0.24f, 0.24f, 0.28f, 1f);
            codeInputImage.raycastTarget = true;

            var viewportObj = new GameObject("TextViewport");
            viewportObj.transform.SetParent(codeInputObj.transform, false);
            var viewport = viewportObj.AddComponent<RectTransform>();
            viewport.anchorMin = Vector2.zero;
            viewport.anchorMax = Vector2.one;
            viewport.sizeDelta = new Vector2(-24, -8);
            viewport.anchoredPosition = Vector2.zero;
            viewportObj.AddComponent<RectMask2D>();

            codeInput = codeInputObj.AddComponent<TMP_InputField>();
            codeInput.targetGraphic = codeInputImage;
            codeInput.textViewport = viewport;
            codeInput.textComponent = CreateCodeInputText(viewportObj);
            codeInput.placeholder = CreateCodePlaceholderText(viewportObj);
            codeInput.characterLimit = 32;
            codeInput.lineType = TMP_InputField.LineType.SingleLine;
            codeInput.caretWidth = 3;
            codeInput.caretColor = Color.white;
            codeInput.customCaretColor = true;
            codeInput.caretBlinkRate = 0.85f;
            codeInput.selectionColor = new Color(0.65f, 0.8f, 1f, 0.5f);
            codeInput.enabled = false;
            codeInput.enabled = true;
            codeInput.gameObject.SetActive(false);

            joinButton = CreateUtilityButton("Join", Vector2.zero, OnJoinClicked);
            joinButton.gameObject.SetActive(false);
            friendliesBackButton = CreateUtilityButton("Back", Vector2.zero, OnFriendliesBackClicked);
            friendliesBackButton.gameObject.SetActive(false);
        }

        private GameObject CreateFriendliesLabel(string name, string title, float fontSize)
        {
            var go = new GameObject(name);
            go.transform.SetParent(panel.transform, false);
            go.AddComponent<RectTransform>();
            var text = go.AddComponent<TextMeshProUGUI>();
            text.text = title;
            text.fontSize = fontSize;
            text.alignment = TextAlignmentOptions.Center;
            text.color = Color.white;
            text.raycastTarget = false;
            text.enableWordWrapping = false;
            go.SetActive(false);
            return go;
        }

        private static void SetLayout(GameObject go, float x, float y, float width, float height)
        {
            var rect = go.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = rect.pivot = new Vector2(0.5f, 0.5f);
            rect.localScale = Vector3.one;
            rect.localRotation = Quaternion.identity;
            rect.anchoredPosition = new Vector2(x, y);
            rect.sizeDelta = new Vector2(width, height);
        }

        private void ApplyFriendliesLayout()
        {
            // All rows use the same panel-centred coordinates, including status.
            SetLayout(friendliesTitle, 0, 215, 600, 60);
            SetLayout(hostButton.gameObject, 0, 140, 300, 58);
            SetLayout(codeLabel, 0, 80, 560, 32);
            SetLayout(codeInput.gameObject, 0, 25, 560, 54);
            SetLayout(codeKeyboardHint, 0, -25, 620, 24);
            SetLayout(pasteButton.gameObject, -145, -80, 250, 54);
            SetLayout(joinButton.gameObject, 145, -80, 250, 54);
            SetLayout(statusText.gameObject, 0, -143, 620, 58);
            SetLayout(friendliesBackButton.gameObject, 0, -205, 300, 54);
            SetLayout(controlHints, 0, -254, 650, 20);
            statusText.fontSize = 24;
            statusText.enableAutoSizing = true;
            statusText.fontSizeMin = 18;
            statusText.fontSizeMax = 24;
            statusText.raycastTarget = false;
            statusText.overflowMode = TextOverflowModes.Ellipsis;
            var hints = controlHints.GetComponent<TextMeshProUGUI>();
            hints.text = "Stick: move   A: select   B: back   STEAM+X: keyboard";
            hints.fontSize = 20;
            hints.enableWordWrapping = false;
        }

        private TextMeshProUGUI CreateCodeInputText(GameObject parent)
        {
            var textObj = new GameObject("Text");
            textObj.transform.SetParent(parent.transform, false);

            var rectTransform = textObj.AddComponent<RectTransform>();
            rectTransform.anchorMin = Vector2.zero;
            rectTransform.anchorMax = Vector2.one;
            rectTransform.sizeDelta = Vector2.zero;
            rectTransform.anchoredPosition = Vector2.zero;

            var text = textObj.AddComponent<TextMeshProUGUI>();
            text.alignment = TextAlignmentOptions.Center;
            text.verticalAlignment = VerticalAlignmentOptions.Middle;
            text.fontSize = 30;
            text.color = Color.white;
            text.margin = new Vector4(10, 0, 10, 0);

            text.raycastTarget = false;
            return text;
        }

        private TextMeshProUGUI CreateCodePlaceholderText(GameObject parent)
        {
            var placeholderObj = new GameObject("Placeholder");
            placeholderObj.transform.SetParent(parent.transform, false);

            var rectTransform = placeholderObj.AddComponent<RectTransform>();
            rectTransform.anchorMin = Vector2.zero;
            rectTransform.anchorMax = Vector2.one;
            rectTransform.sizeDelta = Vector2.zero;
            rectTransform.anchoredPosition = Vector2.zero;

            var text = placeholderObj.AddComponent<TextMeshProUGUI>();
            text.text = "Select to enter room code...";
            text.alignment = TextAlignmentOptions.Center;
            text.verticalAlignment = VerticalAlignmentOptions.Middle;
            text.fontSize = 22;
            text.color = new Color(1f, 1f, 1f, 0.3f);
            text.margin = new Vector4(10, 0, 10, 0);

            text.raycastTarget = false;
            return text;
        }

        protected override void Update()
        {
            base.Update();
            if (playerNameInput == null) return;

            bool isFocused = playerNameInput.isFocused;

            if (wasInputFocused && !isFocused)
            {
                OnPlayerNameEndEdit();
            }
            wasInputFocused = isFocused;
        }

        private void OnPlayerNameEndEdit()
        {
            if (playerNameInput == null) return;

            string newName = playerNameInput.text;

            if (string.IsNullOrWhiteSpace(newName))
            {
                playerNameInput.text = ModConfig.PlayerName.Value;
                return;
            }

            if (filter.IsProfanity(newName))
            {
                newName = filter.CensorString(newName);
                playerNameInput.text = newName;
            }

            newName = newName.Trim();

            ModConfig.PlayerName.Value = newName;
            ModConfig.Save();
            Plugin.Log.LogInfo($"Player name updated to: {ModConfig.PlayerName.Value}");
        }

        private void OnCloseClicked()
        {
            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiSelect.sounds[0]);
            CloseModal();
        }

        private void OnRandomClicked()
        {
            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiSelect.sounds[0]);

            Plugin.Instance.Mode.Mode = NetworkModeType.Random;

            UpdateModalContents(false);

            ShowLoader("Connecting...");

            Plugin.Instance.NetworkHandler.HandleNetworking();
            connectionCoroutine = CoroutineRunner.Instance.Run(HandleConnectionStatus());
        }

        private void OnFriendliesClicked()
        {
            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiSelect.sounds[0]);

            Plugin.Instance.Mode.Mode = NetworkModeType.Friendlies;

            UpdateModalContents(false);
            UpdateFriendliesUI(true);
        }

        private void OnHostClicked()
        {
            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiSelect.sounds[0]);

            Plugin.Instance.Mode.Mode = NetworkModeType.Friendlies;
            Plugin.Instance.Mode.Role = Role.Host;

            UpdateFriendliesUI(false);

            ShowLoader("Connecting...");

            Plugin.Instance.NetworkHandler.HandleNetworking();
            connectionCoroutine = CoroutineRunner.Instance.Run(HandleFriendlies());
        }

        private void OnJoinClicked()
        {
            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiSelect.sounds[0]);

            var code = codeInput.text.Trim().ToUpperInvariant();
            if (!IsValidRoom(code))
            {
                SetStatusText("Enter a room code (4Ã¢â‚¬â€œ32 letters or numbers).");
                return;
            }

            Plugin.Instance.Mode.Mode = NetworkModeType.Friendlies;
            Plugin.Instance.Mode.Role = Role.Client;
            Plugin.Instance.Mode.RoomCode = code;
            lastRoom = code;

            UpdateFriendliesUI(false);

            ShowLoader("Joining room...");

            Plugin.Instance.NetworkHandler.HandleNetworking();
            connectionCoroutine = CoroutineRunner.Instance.Run(HandleFriendlies());
        }

        private void OnFriendliesBackClicked()
        {
            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiSelect.sounds[0]);

            UpdateFriendliesUI(false);
            SetStatusText("");
            UpdateModalContents(true);
        }

        private void OnNetplayOptionsClicked()
        {
            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiSelect.sounds[0]);

            UpdateModalContents(false);
            UpdateNetplayOptionsUI(true);
        }

        private void OnNetplayOptionsBackClicked()
        {
            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiSelect.sounds[0]);

            UpdateNetplayOptionsUI(false);
            UpdateModalContents(true);
        }

        private void OnStopClicked()
        {
            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiSelect.sounds[0]);

            if (connectionCoroutine != null)
            {
                CoroutineRunner.Instance.StopCoroutine(connectionCoroutine);
                connectionCoroutine = null;
            }

            Plugin.Instance.NetworkHandler.ResetNetworking();

            HideLoader();

            UpdateModalContents(true);
            stopButton.gameObject.SetActive(false);

            var closeTextWrapper = closeButton.gameObject.GetComponent<ButtonTextWrapper>();
            closeTextWrapper.t_text.text = "Close";
            SetStatusText("");
        }

        private void UpdateModalContents(bool isVisible)
        {
            randomButton.gameObject.SetActive(isVisible);
            friendliesButton.gameObject.SetActive(isVisible);
            netplayOptionsButton.gameObject.SetActive(isVisible);
            closeButton.gameObject.SetActive(isVisible);
            playerNameInput.gameObject.SetActive(isVisible);
            label.SetActive(isVisible);
        }

        private void UpdateFriendliesUI(bool isVisible)
        {
            if (pasteButton != null) pasteButton.gameObject.SetActive(isVisible);
            friendliesTitle.SetActive(isVisible);
            hostButton.gameObject.SetActive(isVisible);
            codeLabel.SetActive(isVisible);
            codeKeyboardHint.SetActive(isVisible);
            codeInput.gameObject.SetActive(isVisible);
            joinButton.gameObject.SetActive(isVisible);
            friendliesBackButton.gameObject.SetActive(isVisible);
        }

        private void UpdateNetplayOptionsUI(bool isVisible)
        {
            netplayOptionsTitle.SetActive(isVisible);
            saveToggleSetting.SetActive(isVisible);
            sharedExpToggleSetting.SetActive(isVisible);
            netplayOptionsBackButton.gameObject.SetActive(isVisible);
        }

        private IEnumerator HandleConnectionStatus()
        {
            stopButton.gameObject.SetActive(true);
            var stopTextWrapper = stopButton.gameObject.GetComponent<ButtonTextWrapper>();
            stopTextWrapper.t_text.text = "Stop";

            float timeout = 30f;
            float elapsed = 0f;

            while (elapsed < timeout && !Plugin.Instance.NetworkHandler.IsConnectedToMatchMaker.HasValue)
            {
                yield return new WaitForSeconds(0.5f);
                elapsed += 0.5f;
            }

            if (!Plugin.Instance.NetworkHandler.IsConnectedToMatchMaker.Value)
            {
                HideLoader();
                SetStatusText($"Failed to connect to server : {Plugin.Instance.NetworkHandler.MatchMakerFailureMessage}");
                Plugin.Instance.NetworkHandler.ResetNetworking();

                stopButton.gameObject.SetActive(false);
                yield return new WaitForSeconds(4f);
                UpdateModalContents(true);
                SetStatusText("");

                yield break;
            }

            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiSelect.sounds[0]);
            var sharedExpStatus = ModConfig.EnabledSharedExperience.Value
                ? "<color=green>ON</color>"
                : "<color=red>OFF</color>";
            SetStatusText($"Waiting for a match... \n (You can only match people with shared experience {sharedExpStatus})");

            while (!Plugin.Instance.NetworkHandler.HasFoundMatch.HasValue)
            {
                if (Plugin.Instance.NetworkHandler.IsNetworkInterruptedStatus)
                {
                    HideLoader();
                    SetStatusText($"Network interrupted. Please try again : {Plugin.Instance.NetworkHandler.MatchMakerFailureMessage}");
                    Plugin.Instance.NetworkHandler.ResetNetworking();

                    stopButton.gameObject.SetActive(false);

                    yield return new WaitForSeconds(3f);
                    UpdateModalContents(true);
                    SetStatusText("");
                    yield break;
                }
                yield return new WaitForSeconds(0.5f);
            }

            if (!Plugin.Instance.NetworkHandler.HasFoundMatch.HasValue || !Plugin.Instance.NetworkHandler.HasFoundMatch.Value)
            {
                HideLoader();
                SetStatusText($"Failed to connect: {Plugin.Instance.NetworkHandler.MatchMakerFailureMessage}");
                Plugin.Instance.NetworkHandler.ResetNetworking();
                stopButton.gameObject.SetActive(false);
                yield return new WaitForSeconds(4f);
                UpdateModalContents(true);
                SetStatusText("");
                yield break;
            }

            AudioManager.Instance.PlaySfx(AudioManager.Instance.purchaseSfx.sounds[0]);
            HideLoader();
            SetStatusText("Match found!");
            stopButton.gameObject.SetActive(false);

            // Release controller ownership before opening the native character window.
            DeckMenuControls.ReleaseModal(this);
            mainMenu.GoToCharacterSelection();

            var characterMenu = WindowManager.activeWindow as CharacterMenu;
            if (characterMenu != null)
            {
                characterMenu.selectedButton = characterMenu.characterButtons[0];
                characterMenu.b_confirm.SetInteractable(false);
            }

            var role = Plugin.Instance.NetworkHandler.IsHost ? "Host" : "Client";
            var lobbySize = Plugin.Instance.NetworkHandler.GetLobbySize();
            Plugin.StartNotification(("MegabonkTogether", "MatchSuccess"), ("MegabonkTogether", "MatchSuccessDesc"), [role, lobbySize.ToString()]);

            yield return new WaitForSecondsRealtime(1f);
            CloseModal();
        }

        private IEnumerator HandleFriendlies()
        {
            stopButton.gameObject.SetActive(true);
            var stopTextWrapper = stopButton.gameObject.GetComponent<ButtonTextWrapper>();
            stopTextWrapper.t_text.text = "Stop";

            float timeout = 30f;
            float elapsed = 0f;

            while (elapsed < timeout && !Plugin.Instance.NetworkHandler.IsConnectedToMatchMaker.HasValue)
            {
                yield return new WaitForSeconds(0.5f);
                elapsed += 0.5f;
            }

            if (!Plugin.Instance.NetworkHandler.IsConnectedToMatchMaker.Value)
            {
                HideLoader();
                SetStatusText($"Failed to connect to server : {Plugin.Instance.NetworkHandler.MatchMakerFailureMessage}");
                Plugin.Instance.NetworkHandler.ResetNetworking();

                stopButton.gameObject.SetActive(false);
                yield return new WaitForSeconds(4f);
                UpdateFriendliesUI(true);
                SetStatusText("");

                yield break;
            }

            AudioManager.Instance.PlaySfx(AudioManager.Instance.uiSelect.sounds[0]);

            elapsed = 0f;

            while (elapsed < timeout && !Plugin.Instance.NetworkHandler.HasFoundMatch.HasValue)
            {
                if (Plugin.Instance.NetworkHandler.IsNetworkInterruptedStatus)
                {
                    HideLoader();
                    SetStatusText($"Network interrupted. Please try again : {Plugin.Instance.NetworkHandler.MatchMakerFailureMessage}");
                    Plugin.Instance.NetworkHandler.ResetNetworking();

                    stopButton.gameObject.SetActive(false);

                    yield return new WaitForSeconds(3f);
                    UpdateFriendliesUI(true);
                    SetStatusText("");
                    yield break;
                }
                yield return new WaitForSeconds(0.5f);
                elapsed += 0.5f;
            }

            if (!Plugin.Instance.NetworkHandler.HasFoundMatch.HasValue || !Plugin.Instance.NetworkHandler.HasFoundMatch.Value)
            {
                HideLoader();
                SetStatusText($"Failed to connect: {Plugin.Instance.NetworkHandler.MatchMakerFailureMessage}");
                Plugin.Instance.NetworkHandler.ResetNetworking();
                stopButton.gameObject.SetActive(false);
                yield return new WaitForSeconds(4f);
                UpdateFriendliesUI(true);
                SetStatusText("");
                yield break;
            }

            AudioManager.Instance.PlaySfx(AudioManager.Instance.purchaseSfx.sounds[0]);
            HideLoader();
            SetStatusText("Joined!");
            stopButton.gameObject.SetActive(false);

            // Release controller ownership before opening the native character window.
            DeckMenuControls.ReleaseModal(this);
            mainMenu.GoToCharacterSelection();

            var characterMenu = WindowManager.activeWindow as CharacterMenu;
            if (characterMenu != null)
            {
                characterMenu.selectedButton = characterMenu.characterButtons[0];
                characterMenu.b_confirm.SetInteractable(false);
            }

            if (Plugin.Instance.NetworkHandler.IsHost)
            {
                Plugin.StartNotification(("MegabonkTogether", "FriendliesHostSuccess"), ("MegabonkTogether", "FriendliesHostSuccessDesc"), []);
            }
            else
            {
                Plugin.StartNotification(("MegabonkTogether", "FriendliesClientSuccess"), ("MegabonkTogether", "FriendliesClientSuccessDesc"), [""]);
            }

            yield return new WaitForSecondsRealtime(1f);
            CloseModal();
        }
    }
}