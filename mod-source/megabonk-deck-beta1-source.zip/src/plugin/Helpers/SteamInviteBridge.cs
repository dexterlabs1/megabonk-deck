using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using MegabonkTogether.Common.Models;
using UnityEngine;

namespace MegabonkTogether.Helpers
{
    // Uses the Steam client already initialized by Megabonk. Never initializes,
    // shuts down, or drains Steam's callback queue on the game's behalf.
    internal static class SteamInviteBridge
    {
        private const string Dll = "steam_api64";
        private const string Prefix = "+megabonk_together_room ";
        private static IntPtr friends, callback, vtable;
        private static bool ready, unavailable;
        private static string publishedRoom, pendingRoom;
        private static float retryAt;
        private static readonly object Gate = new();
        private static readonly RunDelegate Run = OnCallback;
        private static readonly RunResultDelegate RunResult = OnResult;
        private static readonly SizeDelegate GetSize = Size;

        [UnmanagedFunctionPointer(CallingConvention.ThisCall)] private delegate void RunDelegate(IntPtr self, IntPtr data);
        [UnmanagedFunctionPointer(CallingConvention.ThisCall)] private delegate void RunResultDelegate(IntPtr self, IntPtr data, [MarshalAs(UnmanagedType.I1)] bool failed, ulong call);
        [UnmanagedFunctionPointer(CallingConvention.ThisCall)] private delegate int SizeDelegate(IntPtr self);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] private static extern IntPtr SteamAPI_SteamFriends_v017();
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] private static extern IntPtr SteamAPI_SteamUtils_v010();
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] private static extern IntPtr SteamAPI_SteamApps_v008();
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] private static extern void SteamAPI_RegisterCallback(IntPtr callback, int id);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] private static extern void SteamAPI_UnregisterCallback(IntPtr callback);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] [return: MarshalAs(UnmanagedType.I1)]
        private static extern bool SteamAPI_ISteamFriends_SetRichPresence(IntPtr self, [MarshalAs(UnmanagedType.LPUTF8Str)] string key, [MarshalAs(UnmanagedType.LPUTF8Str)] string value);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] private static extern void SteamAPI_ISteamFriends_ActivateGameOverlayInviteDialogConnectString(IntPtr self, [MarshalAs(UnmanagedType.LPUTF8Str)] string connect);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] private static extern int SteamAPI_ISteamApps_GetLaunchCommandLine(IntPtr self, StringBuilder buffer, int size);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] [return: MarshalAs(UnmanagedType.I1)]
        private static extern bool SteamAPI_ISteamUtils_ShowFloatingGamepadTextInput(IntPtr self, int mode, int x, int y, int width, int height);

        internal static string ParseRoom(string text)
        {
            if (text == null || text.Length > 4096) return null;
            var m = Regex.Match(text, @"(?:^|\s)\+megabonk_together_room ([A-Za-z0-9]{4,32})(?=\s|$)");
            return m.Success ? m.Groups[1].Value.ToUpperInvariant() : null;
        }

        private static void Queue(string text)
        {
            string room = ParseRoom(text);
            if (room != null) lock (Gate) pendingRoom = room;
        }
        // Steam's GameRichPresenceJoinRequested_t: uint64 SteamID + char[256].
        private static void OnCallback(IntPtr self, IntPtr data)
        {
            try
            {
                var room = DecodePayload(data);
                if (room != null) lock (Gate) pendingRoom = room;
            }
            catch (Exception ex) { Plugin.Log.LogWarning("Steam invite callback: " + ex.Message); }
        }
        internal static string DecodePayload(IntPtr data)
        {
            if (data == IntPtr.Zero) return null;
            byte[] bytes = new byte[256];
            Marshal.Copy(IntPtr.Add(data, 8), bytes, 0, bytes.Length);
            int end = Array.IndexOf(bytes, (byte)0);
            return ParseRoom(Encoding.UTF8.GetString(bytes, 0, end < 0 ? bytes.Length : end));
        }

        private static void OnResult(IntPtr self, IntPtr data, bool failed, ulong call) { if (!failed) OnCallback(self, data); }
        private static int Size(IntPtr self) => 264;

        private static bool EnsureReady()
        {
            if (ready) return true;
            if (unavailable || Time.unscaledTime < retryAt) return false;
            retryAt = Time.unscaledTime + 5f;
            try
            {
                if (IntPtr.Size != 8 || !RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) return false;
                friends = SteamAPI_SteamFriends_v017();
                if (friends == IntPtr.Zero) return false;
                // Win64 CCallbackBase layout: vptr @0, flags @8, callback ID @12.
                // Both Run overloads start with (this, data) in the Win64 ABI.
                // Sharing a two-argument thunk ignores the call-result-only extras
                // and avoids depending on MSVC's overloaded-method slot ordering.
                vtable = Marshal.AllocHGlobal(IntPtr.Size * 3);
                Marshal.WriteIntPtr(vtable, 0, Marshal.GetFunctionPointerForDelegate(Run));
                Marshal.WriteIntPtr(vtable, IntPtr.Size, Marshal.GetFunctionPointerForDelegate(Run));
                Marshal.WriteIntPtr(vtable, IntPtr.Size * 2, Marshal.GetFunctionPointerForDelegate(GetSize));
                callback = Marshal.AllocHGlobal(16);
                Marshal.WriteIntPtr(callback, vtable);
                Marshal.WriteInt64(callback, 8, 0);
                Marshal.WriteInt32(callback, 12, 337);
                SteamAPI_RegisterCallback(callback, 337);
                ready = true;
                Queue(Environment.CommandLine);
                var apps = SteamAPI_SteamApps_v008();
                if (apps != IntPtr.Zero)
                {
                    var line = new StringBuilder(4096);
                    SteamAPI_ISteamApps_GetLaunchCommandLine(apps, line, line.Capacity);
                    Queue(line.ToString());
                }
                Plugin.Log.LogInfo("Steam invite bridge registered (Deck beta).");
                return true;
            }
            catch (Exception ex)
            {
                unavailable = true;
                Plugin.Log.LogWarning("Steam invites unavailable; use the room code: " + ex.Message);
                return false;
            }
        }

        internal static bool IsHostingLobby()
        {
            var mode = Plugin.Instance.Mode;
            var window = WindowManager.activeWindow;
            return mode.Mode == NetworkModeType.Friendlies && mode.Role == Role.Host &&
                Plugin.Instance.NetworkHandler.IsConnectedToMatchMaker == true &&
                window != null && (window.name == "W_Character" || window.name == "Maps And Stats") &&
                Regex.IsMatch(mode.RoomCode ?? "", "^[A-Za-z0-9]{4,32}$");
        }

        internal static bool InviteFriends()
        {
            if (!IsHostingLobby() || !EnsureReady()) return false;
            try
            {
                SteamAPI_ISteamFriends_ActivateGameOverlayInviteDialogConnectString(friends, Prefix + Plugin.Instance.Mode.RoomCode);
                return true;
            }
            catch (Exception ex) { Plugin.Log.LogWarning("Steam invite picker: " + ex.Message); return false; }
        }

        internal static void Tick()
        {
            if (unavailable) return;
            try { TickCore(); }
            catch (Exception ex)
            {
                unavailable = true;
                Plugin.Log.LogWarning("Steam invite integration paused; use room codes: " + ex.Message);
            }
        }

        private static void TickCore()
        {
            if (!EnsureReady()) return;
            string room = IsHostingLobby() ? Plugin.Instance.Mode.RoomCode : null;
            if (room != publishedRoom)
            {
                // Only touch the connect key owned by this feature, not all of the game's presence.
                SteamAPI_ISteamFriends_SetRichPresence(friends, "connect", room == null ? "" : Prefix + room);
                publishedRoom = room;
            }
            string pending;
            lock (Gate) pending = pendingRoom;
            if (pending == null) return;
            // Never interrupt an active run or replace a live connection.
            if (WindowManager.activeWindow == null || WindowManager.activeWindow.name != "Menu" ||
                Plugin.Instance.NetworkHandler.IsConnectedToMatchMaker == true) return;
            if (Plugin.Instance.PlayTogetherButton == null || Scripts.Modal.DeckMenuControls.IsModalActive && Plugin.Instance.NetworkTab == null) return;
            if (Plugin.Instance.NetworkTab == null) Plugin.Instance.PlayTogetherButton.OnClick();
            if (Plugin.Instance.NetworkTab == null) return;
            Plugin.Instance.NetworkTab.QueueSteamInvite(pending);
            lock (Gate) if (pendingRoom == pending) pendingRoom = null;
        }

        internal static void ShowKeyboard()
        {
            try
            {
                if (!EnsureReady()) return;
                var utils = SteamAPI_SteamUtils_v010();
                if (utils != IntPtr.Zero)
                    SteamAPI_ISteamUtils_ShowFloatingGamepadTextInput(utils, 0, Screen.width / 4, Screen.height / 3, Screen.width / 2, 80);
            }
            catch (Exception ex) { Plugin.Log.LogDebug("Use STEAM+X for text entry: " + ex.Message); }
        }
    }
}
