using Assets.Scripts.Managers;
using MegabonkTogether.Helpers;
using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace MegabonkTogether.Scripts.Modal
{
    // Reuse Megabonk's own navigation/input mapping rather than polling raw
    // joystick buttons or changing Steam Input bindings.
    public class DeckMenuControls : MonoBehaviour
    {
        private static DeckMenuControls instance;
        public void Awake() { instance = this; }
        internal static void ReleaseModal(ModalBase modal)
        {
            Modals.Remove(modal);
            if (instance != null && instance.currentModal == modal) instance.RestoreWindow();
        }
        private Window owner;
        private Il2CppSystem.Collections.Generic.HashSet<GameObject> savedButtonSet;
        private Il2CppSystem.Collections.Generic.List<MyButton> savedButtons;
        private MyButton savedSelection;
        private ModalBase currentModal;
        private bool cursorOwned;
        private bool savedCursorVisible;
        private CursorLockMode savedCursorLock;
        private int previousSignature;
        private readonly Dictionary<UnityEngine.UI.Button, Navigation> backgroundNavigation = new();
        private Il2CppSystem.Collections.Generic.List<MyButton> modalButtons;
        private Il2CppSystem.Collections.Generic.HashSet<GameObject> modalButtonSet;
        private bool announceOwnership;
        private readonly Dictionary<MaskableGraphic, Color> modalColors = new();
        private static readonly Color ControllerFocusColor = new Color(0.95f, 0.65f, 0.12f, 1f);
        private bool loggedFailure;
        internal static readonly List<ModalBase> Modals = new();
        internal static bool IsEditingText
        {
            get
            {
                var modal = TopModal();
                if (modal == null) return false;
                foreach (var input in modal.NavigationPanel.RuntimeGetComponentsInChildren<TMP_InputField>())
                    if (input.isFocused) return true;
                return false;
            }
        }
        internal static bool IsModalActive => TopModal() != null;

        private static ModalBase TopModal()
        {
            for (int i = Modals.Count - 1; i >= 0; --i)
            {
                var modal = Modals[i];
                if (modal == null) { Modals.RemoveAt(i); continue; }
                // The network entry dialog belongs only to the main menu. Its
                // success coroutine may still be finishing after a window change.
                if (modal is NetworkMenuTab && WindowManager.activeWindow?.name != "Menu") continue;
                if (modal.NavigationPanel != null && modal.NavigationPanel.activeInHierarchy)
                    return modal;
            }
            return null;
        }

        public void LateUpdate()
        {
            try { Tick(); }
            catch (Exception ex)
            {
                RestoreWindow();
                if (!loggedFailure) { Plugin.Log.LogError("Deck menu controls: " + ex); loggedFailure = true; }
            }
        }

        private void Tick()
        {
            var modal = TopModal();
            var active = WindowManager.activeWindow;
            bool menu = modal != null || (active != null && active.name == "Menu");
            if (menu)
            {
                if (!cursorOwned)
                {
                    savedCursorVisible = Cursor.visible;
                    savedCursorLock = Cursor.lockState;
                    cursorOwned = true;
                }
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
            else RestoreCursor();

            if (owner != active || currentModal != modal)
            {
                RestoreWindow();
                if (modal != null && active != null)
                {
                    owner = active;
                    savedButtons = active.allButtons;
                    savedButtonSet = active.allButtonsHashed;
                    savedSelection = ButtonManager.selectedButton2;
                    currentModal = modal;
                    previousSignature = 0;
                    SuppressBackgroundNavigation();
                    announceOwnership = true;
                }
            }
            if (owner == null || modal == null) return;

            var buttons = new Il2CppSystem.Collections.Generic.List<MyButton>();
            int signature = 17;
            foreach (var button in modal.NavigationPanel.RuntimeGetComponentsInChildren<MyButton>())
            {
                if (button == null || !button.gameObject.activeInHierarchy || button.state != MyButton.EButtonState.Active)
                    continue;
                buttons.Add(button);
                var visual = button.gameObject.GetComponent<MyButtonNormal>();
                if (visual != null && visual.background != null && !modalColors.ContainsKey(visual.background))
                    modalColors.Add(visual.background, visual.background.color);
                signature = unchecked(signature * 31 + button.GetInstanceID());
            }
            if (modalButtons == null || signature != previousSignature)
            {
                modalButtons = buttons;
                modalButtonSet = new Il2CppSystem.Collections.Generic.HashSet<GameObject>();
                foreach (var button in buttons) modalButtonSet.Add(button.gameObject);
                previousSignature = signature;
            }
            // Unity Automatic navigation searches every active Selectable, not just
            // Window.allButtons. Keep background navigation disabled and repair
            // focus even when this modal's button membership has not changed.
            owner.allButtons = modalButtons;
            owner.allButtonsHashed = modalButtonSet;
            var selected = ButtonManager.selectedButton2;
            if (selected == null || !modalButtons.Contains(selected))
            {
                var preferred = modal.DefaultControllerButton;
                if (preferred != null && modalButtons.Contains(preferred)) ButtonManager.ForceHoverButton(preferred);
                else if (modalButtons.Count > 0) ButtonManager.ForceHoverButton(modalButtons[0]);
                else ButtonManager.SetNull();
            }
            PaintControllerFocus(IsEditingText ? null : ButtonManager.selectedButton2);
            if (announceOwnership)
            {
                Plugin.Log.LogInfo($"Deck modal focus: {modal.GetType().Name}; window={owner.name}; buttons={modalButtons.Count}; graphics={modalColors.Count}; selected={ButtonManager.selectedButton2?.GetInstanceID()}");
                announceOwnership = false;
            }

            // Read the underlying player here; the prefix suppresses only
            // cancel/abort in the background game's normal window handlers.
            var player = MyInputManager.GetPlayer();
            if (player != null && player.GetButtonDown(MyInputManager.UICancel))
            {
                foreach (var input in modal.NavigationPanel.RuntimeGetComponentsInChildren<TMP_InputField>())
                {
                    if (input.isFocused) { input.DeactivateInputField(); return; }
                }
                modal.ControllerBack();
            }
        }

        private void PaintControllerFocus(MyButton selected)
        {
            // Refresh after native navigation each frame; injected hover callbacks
            // are not consistently dispatched by every controller selection path.
            foreach (var pair in modalColors)
                if (pair.Key != null) pair.Key.color = pair.Value;
            if (selected == null) return;
            var visual = selected.gameObject.GetComponent<MyButtonNormal>();
            if (visual != null && visual.background != null && modalColors.ContainsKey(visual.background))
                visual.background.color = ControllerFocusColor;
        }

        private void SuppressBackgroundNavigation()
        {
            if (savedButtons == null) return;
            foreach (var button in savedButtons)
            {
                if (button == null || button.button == null || backgroundNavigation.ContainsKey(button.button)) continue;
                var native = button.button;
                var navigation = native.navigation;
                backgroundNavigation.Add(native, navigation);
                navigation.mode = Navigation.Mode.None;
                native.navigation = navigation;
            }
        }

        private void RestoreWindow()
        {
            foreach (var pair in backgroundNavigation)
                if (pair.Key != null) pair.Key.navigation = pair.Value;
            backgroundNavigation.Clear();
            foreach (var pair in modalColors)
                if (pair.Key != null) pair.Key.color = pair.Value;
            modalColors.Clear();
            modalButtons = null;
            modalButtonSet = null;
            announceOwnership = false;
            if (owner != null)
            {
                owner.allButtons = savedButtons;
                owner.allButtonsHashed = savedButtonSet;
                if (owner == WindowManager.activeWindow && savedSelection != null && savedSelection.gameObject.activeInHierarchy)
                    ButtonManager.ForceHoverButton(savedSelection);
            }
            owner = null;
            currentModal = null;
            savedButtons = null;
            savedButtonSet = null;
            savedSelection = null;
        }

        private void RestoreCursor()
        {
            if (!cursorOwned) return;
            Cursor.visible = savedCursorVisible;
            Cursor.lockState = savedCursorLock;
            cursorOwned = false;
        }

        public void OnDestroy() { RestoreWindow(); RestoreCursor(); }
    }
}
