using System.Text.RegularExpressions;
namespace MegabonkTogether.Helpers
{
    internal static class RoomCodeTools
    {
        internal static string ParseRoom(string text)
        {
            if (text == null || text.Length > 4096) return null;
            var m = Regex.Match(text, @"(?:^|\s)\+megabonk_together_room ([A-Za-z0-9]{4,32})(?=\s|$)");
            return m.Success ? m.Groups[1].Value.ToUpperInvariant() : null;
        }

    }
}
