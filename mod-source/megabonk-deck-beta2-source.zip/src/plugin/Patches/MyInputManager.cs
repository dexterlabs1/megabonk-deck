using HarmonyLib;
using MegabonkTogether.Common;
using Microsoft.Extensions.DependencyInjection;

namespace MegabonkTogether.Patches
{
    [HarmonyPatch(typeof(MyInputManager))]
    internal static class MyInputManagerPatches
    {
        private static readonly IAutoUpdaterService autoUpdaterService = Plugin.Services.GetService<IAutoUpdaterService>();

        [HarmonyPrefix]
        [HarmonyPatch(nameof(MyInputManager.GetAxis))]
        public static bool GetAxis_Prefix(string __0, ref float __result)
        {
            if (Scripts.Modal.DeckMenuControls.IsEditingText &&
                (__0 == MyInputManager.UIHorizontal || __0 == MyInputManager.UIVertical))
            { __result = 0; return false; }
            return true;
        }

        /// <summary>
        /// Prevent input when an update is available
        /// </summary>
        [HarmonyPrefix]
        [HarmonyPatch(nameof(MyInputManager.GetButtonDown))]
        public static bool GetButtonDown_Prefix(string __0, ref bool __result)
        {
            if (Scripts.Modal.DeckMenuControls.IsModalActive &&
                (__0 == MyInputManager.UICancel || __0 == MyInputManager.UIAbort))
            {
                __result = false;
                return false;
            }
            if (Scripts.Modal.DeckMenuControls.IsModalActive && __0 == MyInputManager.UISubmit &&
                UnityEngine.Time.unscaledTime < Scripts.Modal.ModalBase.SubmitReadyAt)
            { __result = false; return false; }
            if (Scripts.Modal.DeckMenuControls.IsEditingText && __0 == MyInputManager.UISubmit)
            { __result = false; return false; }
            if (autoUpdaterService.IsAnUpdateAvailable())
            {
                __result = false;
                return false;
            }
            return true;
        }

        /// <summary>
        /// Prevent input when an update is available
        /// </summary>
        [HarmonyPrefix]
        [HarmonyPatch(nameof(MyInputManager.GetButtonUp))]
        public static bool GetButtonUp_Prefix(string __0, ref bool __result)
        {
            if (Scripts.Modal.DeckMenuControls.IsModalActive &&
                (__0 == MyInputManager.UICancel || __0 == MyInputManager.UIAbort))
            {
                __result = false;
                return false;
            }
            if (Scripts.Modal.DeckMenuControls.IsModalActive && __0 == MyInputManager.UISubmit &&
                UnityEngine.Time.unscaledTime < Scripts.Modal.ModalBase.SubmitReadyAt)
            { __result = false; return false; }
            if (Scripts.Modal.DeckMenuControls.IsEditingText && __0 == MyInputManager.UISubmit)
            { __result = false; return false; }
            if (autoUpdaterService.IsAnUpdateAvailable())
            {
                __result = false;
                return false;
            }
            return true;
        }

        /// <summary>
        /// Prevent input when an update is available
        /// </summary>
        [HarmonyPrefix]
        [HarmonyPatch(nameof(MyInputManager.GetButton))]
        public static bool GetButton_Prefix(string __0, ref bool __result)
        {
            if (Scripts.Modal.DeckMenuControls.IsModalActive &&
                (__0 == MyInputManager.UICancel || __0 == MyInputManager.UIAbort))
            {
                __result = false;
                return false;
            }
            if (Scripts.Modal.DeckMenuControls.IsModalActive && __0 == MyInputManager.UISubmit &&
                UnityEngine.Time.unscaledTime < Scripts.Modal.ModalBase.SubmitReadyAt)
            { __result = false; return false; }
            if (Scripts.Modal.DeckMenuControls.IsEditingText && __0 == MyInputManager.UISubmit)
            { __result = false; return false; }
            if (autoUpdaterService.IsAnUpdateAvailable())
            {
                __result = false;
                return false;
            }
            return true;
        }

    }


}
