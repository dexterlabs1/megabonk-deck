using Assets.Scripts.Managers;
using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace MegabonkTogether.Scripts.Modal
{
    // Reuse Megabonk's own navigation/input mapping rather than polling raw
    // joystick buttons or changing Steam Input bindings.
    public class DeckMenuControls : MonoBehaviour
    {
        private static DeckMenuControls instance;
        public void Awake() { instance = this; }
        internal static void ReleaseModal(ModalBase modal)
        {
            Modals.Remove(modal);
            if (instance != null && instance.currentModal == modal) instance.RestoreWindow();
        }
        private Window owner;
        private Il2CppSystem.Collections.Generic.HashSet<GameObject> savedButtonSet;
        private Il2CppSystem.Collections.Generic.List<MyButton> savedButtons;
        private MyButton savedSelection;
        private ModalBase currentModal;
        private bool cursorOwned;
        private bool savedCursorVisible;
        private CursorLockMode savedCursorLock;
        private int previousSignature;
        private bool loggedFailure;
        internal static readonly List<ModalBase> Modals = new();
        internal static bool IsEditingText
        {
            get
            {
                var modal = TopModal();
                if (modal == null) return false;
                foreach (var input in modal.NavigationPanel.GetComponentsInChildren<TMP_InputField>())
                    if (input.isFocused) return true;
                return false;
            }
        }
        internal static bool IsModalActive => TopModal() != null;

        private static ModalBase TopModal()
        {
            for (int i = Modals.Count - 1; i >= 0; --i)
            {
                var modal = Modals[i];
                if (modal == null) { Modals.RemoveAt(i); continue; }
                if (modal.NavigationPanel != null && modal.NavigationPanel.activeInHierarchy)
                    return modal;
            }
            return null;
        }

        public void LateUpdate()
        {
            try { Tick(); }
            catch (Exception ex)
            {
                RestoreWindow();
                if (!loggedFailure) { Plugin.Log.LogError("Deck menu controls: " + ex); loggedFailure = true; }
            }
        }

        private void Tick()
        {
            var modal = TopModal();
            var active = WindowManager.activeWindow;
            bool menu = modal != null || (active != null && active.name == "Menu");
            if (menu)
            {
                if (!cursorOwned)
                {
                    savedCursorVisible = Cursor.visible;
                    savedCursorLock = Cursor.lockState;
                    cursorOwned = true;
                }
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
            else RestoreCursor();

            if (owner != active || currentModal != modal)
            {
                RestoreWindow();
                if (modal != null && active != null)
                {
                    owner = active;
                    savedButtons = active.allButtons;
                    savedButtonSet = active.allButtonsHashed;
                    savedSelection = ButtonManager.selectedButton2;
                    currentModal = modal;
                    previousSignature = 0;
                }
            }
            if (owner == null || modal == null) return;

            var buttons = new Il2CppSystem.Collections.Generic.List<MyButton>();
            int signature = 17;
            foreach (var button in modal.NavigationPanel.GetComponentsInChildren<MyButton>())
            {
                if (button == null || !button.gameObject.activeInHierarchy || button.state != MyButton.EButtonState.Active)
                    continue;
                buttons.Add(button);
                signature = unchecked(signature * 31 + button.GetInstanceID());
            }
            if (signature != previousSignature)
            {
                owner.allButtons = buttons;
                var set = new Il2CppSystem.Collections.Generic.HashSet<GameObject>();
                foreach (var button in buttons) set.Add(button.gameObject);
                owner.allButtonsHashed = set;
                previousSignature = signature;
                var selected = ButtonManager.selectedButton2;
                if (selected == null || !buttons.Contains(selected))
                {
                    var preferred = modal.DefaultControllerButton;
                    if (preferred != null && buttons.Contains(preferred)) ButtonManager.ForceHoverButton(preferred);
                    else if (buttons.Count > 0) ButtonManager.ForceHoverButton(buttons[0]);
                    else ButtonManager.SetNull();
                }
            }

            // Read the underlying player here; the prefix suppresses only
            // cancel/abort in the background game's normal window handlers.
            var player = MyInputManager.GetPlayer();
            if (player != null && player.GetButtonDown(MyInputManager.UICancel))
            {
                foreach (var input in modal.NavigationPanel.GetComponentsInChildren<TMP_InputField>())
                {
                    if (input.isFocused) { input.DeactivateInputField(); return; }
                }
                modal.ControllerBack();
            }
        }

        private void RestoreWindow()
        {
            if (owner != null)
            {
                owner.allButtons = savedButtons;
                owner.allButtonsHashed = savedButtonSet;
                if (owner == WindowManager.activeWindow && savedSelection != null && savedSelection.gameObject.activeInHierarchy)
                    ButtonManager.ForceHoverButton(savedSelection);
            }
            owner = null;
            currentModal = null;
            savedButtons = null;
            savedButtonSet = null;
            savedSelection = null;
        }

        private void RestoreCursor()
        {
            if (!cursorOwned) return;
            Cursor.visible = savedCursorVisible;
            Cursor.lockState = savedCursorLock;
            cursorOwned = false;
        }

        public void OnDestroy() { RestoreWindow(); RestoreCursor(); }
    }
}
