using System.Reflection;
using System.Runtime.InteropServices;
System.Runtime.Loader.AssemblyLoadContext.Default.Resolving += (context, name) =>
{
    foreach (var folder in args.Skip(1).Append(Path.GetDirectoryName(Path.GetFullPath(args[0]))!))
    {
        var path = Path.Combine(folder, name.Name + ".dll");
        if (File.Exists(path)) return context.LoadFromAssemblyPath(Path.GetFullPath(path));
    }
    return null;
};
var plugin = Assembly.LoadFrom(Path.GetFullPath(args[0]));
var bridge = plugin.GetType("MegabonkTogether.Helpers.RoomCodeTools", true)!;
var parse = bridge.GetMethod("ParseRoom", BindingFlags.Static | BindingFlags.NonPublic)!;
string? Parse(string? text) => (string?)parse.Invoke(null, new object?[] { text });
int tests = 0;
void Check(bool condition, string name) { if (!condition) throw new Exception(name); tests++; }
Check(Parse("+megabonk_together_room ABC123") == "ABC123", "normal invite");
Check(Parse("game.exe +megabonk_together_room abc123 -windowed") == "ABC123", "launch args");
foreach (var invalid in new string?[] { null, "", "ABC123", "+megabonk_together_room A", "+megabonk_together_room ../../bad", "+megabonk_together_room ABC123;bad", "x+megabonk_together_room ABC123", new string('x', 4097), "+megabonk_together_room " + new string('A',33) })
    Check(Parse(invalid) == null, "invalid invite rejected");
Check(plugin.GetType("MegabonkTogether.Helpers.SteamInviteBridge") == null, "native Steam bridge removed");
Console.WriteLine($"{tests} room parser/removal checks passed. No Steam API calls made.");
