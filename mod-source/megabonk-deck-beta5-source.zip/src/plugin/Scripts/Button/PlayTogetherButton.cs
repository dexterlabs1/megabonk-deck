using UnityEngine;

namespace MegabonkTogether.Scripts.Button
{
    public class PlayTogetherButton : MyButtonNormal
    {
        private MainMenu mainMenu;

        internal void InitializeFrom(MyButtonNormal template, UnityEngine.UI.Button clonedButton)
        {
            // Adding a managed component does not copy the native component's
            // serialized fields. Navigation needs this clone's Unity Button.
            button = clonedButton;
            if (clonedButton != null)
            {
                // Play can carry an explicit first-row link with no Up target.
                // Together is a new row, so let Unity find its actual neighbours.
                clonedButton.navigation = UnityEngine.UI.Navigation.defaultNavigation;
            }
            if (template == null) return;
            scaleOnHover = template.scaleOnHover;
            hoverScale = template.hoverScale;
            state = template.state;
            disabledOverlay = template.disabledOverlay;
            customSfx = template.customSfx;
            background = template.background;
            defaultColor = template.defaultColor;
            hoverColor = template.hoverColor;
            colorInited = template.colorInited;
        }

        public override void OnClick()
        {
            OnPlayTogetherClick();
        }


        private void OnPlayTogetherClick()
        {
            if (Plugin.Instance.NetworkTab != null) return;

            var networkMenuObj = new GameObject("NetworkMenuTab");
            Plugin.Instance.NetworkTab = networkMenuObj.AddComponent<NetworkMenuTab>();
            Plugin.Instance.NetworkTab.SetMainMenu(mainMenu);
        }

        public void SetMainMenu(MainMenu menu)
        {
            mainMenu = menu;
        }
    }
}
